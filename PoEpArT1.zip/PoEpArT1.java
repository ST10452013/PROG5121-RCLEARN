
package poepart1;
import java.util.Scanner;
public class PoEpArT1 {

    
    private static String userName;
    private static String passWord;
    private static String name;
    private static String surName;
    

    //set to find the username
    public static void setUserName(String name){               
        userName = name;
    }
    public static String getUserName(){
        return userName;
    }
    //set to find the password
    public static void setPassword(String pass){
        passWord = pass;
    }
    public static String getPassword(){
        return passWord;
    }
    //set and get the user's name
    public static void setName(String naame){
        name = naame;
    }
    public static String getName(){
        return name;
    }
    
    //set and get the user's surname
    public static void setSurname(String surname){
        surName = surname;
    }
    public static String getSurname(){
        return surName;
    }
    

    public static void main(String[] args)
    {
    
        LOGIN loginObj = new LOGIN();
                       
     /*Prompt the user for the required input and then pass the input directly to the methods that use it*/   
        Scanner data = new Scanner(System.in);
        System.out.println(" *ENROLLMENT *** ");
        
        System.out.print("Enter your first name: ");
        setName(data.nextLine());
        
        System.out.print("Enter your surname: ");
        setSurname(data.nextLine());
        
        
        System.out.print("Enter your user name: ");
        setUserName(data.nextLine());
        
        loginObj.checkUserName(getUserName()); // ensure the username meets the requirements
        
        System.out.print("Enter your password: ");
        setPassword(data.nextLine());                

        loginObj.checkPasswordComplexity(passWord); // ensure the password meets the requirements
        
        
        /*Progress the username and password to the method and then print out the messages returned by the method*/
        System.out.println( loginObj.registerUser( getPassword(), getUserName() ));
        
        //Save the boolean value returned by loginUser() in the regStatus varible. The boolean value will used in the returnLoginStatus method
        boolean regStatus = loginObj.loginUser(loginObj.checkUserName(getUserName()) ,loginObj.checkPasswordComplexity(getPassword()), getPassword(), getUserName());
        
        System.out.println(loginObj.returnLoginStatus(regStatus, getName(), getSurname()));
    
    }
    
}
